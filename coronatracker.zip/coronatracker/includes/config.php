<?php

$title = "Coronavirus Tracker (CampCodes) - Covid-19 Rate, Map, Country Data";

$mapAPI = "AIzaSyAS47SxwHyxg2oKSU4zD1TjN6CxY20EI0U"; //Note: you will need to get a mapsApiKey for your project. See: https://developers.google.com/chart/interactive/docs/basic_load_libs#load-settings

$ads = "<a href='https://www.campcodes.com' target='_blank'><img src='assets/images/banner.png' style='width: 100%;' /></a>";

$language = "en";
/*
en - English
ar - Arabic
ch - Chineese/Mandarin
es - Spanish
fr - French
hi - Hidi
kr - Korean
pt - Portuguese
ru - Russian
*/
?>