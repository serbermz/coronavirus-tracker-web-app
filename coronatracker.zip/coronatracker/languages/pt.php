<?php
$lang = array();
$lang['total_cases'] = "Total de Casos";
$lang['total_deaths'] = "Total de Mortes";
$lang['total_recovered'] = "Total recuperado";
$lang['location'] = "Localização";
$lang['confirmed_cases'] = "Casos confirmados";
$lang['deaths'] = "Mortes";
$lang['recovered'] = "Recuperado";
$lang['new_cases_today'] = "Novos casos hoje";
$lang['caseper1m'] = "Casos por 1 milhão de pessoas";
$lang['first_case'] = "Data do primeiro caso";
$lang['active_cases'] = "Casos ativos";
$lang['critical_cases'] = "Casos críticos";
$lang['new_deaths_today'] = "Novas mortes hoje";
$lang['mortality_rate'] = "Taxa de mortalidade";
$lang['recovery_rate'] = "Taxa de recuperação";
$lang['total_tests'] = "Total de testes";
?>