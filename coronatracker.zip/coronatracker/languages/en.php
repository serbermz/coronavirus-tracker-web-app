<?php
$lang = array();
$lang['total_cases'] = "Total Cases";
$lang['total_deaths'] = "Total Deaths";
$lang['total_recovered'] = "Total Recovered";
$lang['location'] = "Location";
$lang['confirmed_cases'] = "Confirmed Cases";
$lang['deaths'] = "Deaths";
$lang['recovered'] = "Recovered";
$lang['new_cases_today'] = "New Cases Today";
$lang['caseper1m'] = "Cases per 1M people";
$lang['first_case'] = "First Case Date";
$lang['active_cases'] = "Active Cases";
$lang['critical_cases'] = "Critical Cases";
$lang['new_deaths_today'] = "New Deaths Today";
$lang['mortality_rate'] = "Mortality Rate";
$lang['recovery_rate'] = "Recovery Rate";
$lang['total_tests'] = "Total Tests";
?>