<?php
$lang = array();
$lang['total_cases'] = "إجمالي الحالات";
$lang['total_deaths'] = "إجمالي الوفيات";
$lang['total_recovered'] = "إجمالي المستردة";
$lang['location'] = "موقعك";
$lang['confirmed_cases'] = "الحالات المؤكدة";
$lang['deaths'] = "الوفيات";
$lang['recovered'] = "تعافى";
$lang['new_cases_today'] = "حالات جديدة اليوم";
$lang['caseper1m'] = "عدد الحالات لكل مليون شخص";
$lang['first_case'] = "تاريخ الحالة الأولى";
$lang['active_cases'] = "الحالات النشطة";
$lang['critical_cases'] = "الحالات الحرجة";
$lang['new_deaths_today'] = "وفيات جديدة اليوم";
$lang['mortality_rate'] = "معدل الوفيات";
$lang['recovery_rate'] = "معدل الاسترداد";
$lang['total_tests'] = "إجمالي الاختبارات";
?>