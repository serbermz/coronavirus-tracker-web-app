<?php
$lang = array();
$lang['total_cases'] = "Casos totales";
$lang['total_deaths'] = "Muertes totales";
$lang['total_recovered'] = "Total recuperado";
$lang['location'] = "Ubicacion";
$lang['confirmed_cases'] = "Casos confirmados";
$lang['deaths'] = "Muertes";
$lang['recovered'] = "Recuperado";
$lang['new_cases_today'] = "Nuevos casos hoy";
$lang['caseper1m'] = "Casos por 1 millon de personas";
$lang['first_case'] = "Fecha del primer caso";
$lang['active_cases'] = "Casos activos";
$lang['critical_cases'] = "Casos Cr��ticos";
$lang['new_deaths_today'] = "Nuevas muertes hoy";
$lang['mortality_rate'] = "Tasa de mortalidad";
$lang['recovery_rate'] = "�0�1ndice de recuperaci��n";
$lang['total_tests'] = "Pruebas totales";
?>