<?php
$lang = array();
$lang['total_cases'] = "총 사례";
$lang['total_deaths'] = "총 사망";
$lang['total_recovered'] = "총 회수";
$lang['location'] = "위치";
$lang['confirmed_cases'] = "확인 된 사례";
$lang['deaths'] = "죽음";
$lang['recovered'] = "회복 된";
$lang['new_cases_today'] = "오늘 새로운 사례";
$lang['caseper1m'] = "1M 당 사례";
$lang['first_case'] = "첫 번째 날짜";
$lang['active_cases'] = "활성 사례";
$lang['critical_cases'] = "중요한 경우";
$lang['new_deaths_today'] = "오늘 새로운 죽음";
$lang['mortality_rate'] = "사망률";
$lang['recovery_rate'] = "회복률";
$lang['total_tests'] = "총 테스트";
?>