<?php
$lang = array();
$lang['total_cases'] = "案件总数";
$lang['total_deaths'] = "死亡总数";
$lang['total_recovered'] = "总回收";
$lang['location'] = "位置";
$lang['confirmed_cases'] = "确诊病例";
$lang['deaths'] = "死亡人数";
$lang['recovered'] = "已恢复";
$lang['new_cases_today'] = "今日新案";
$lang['caseper1m'] = "每100万人的案件";
$lang['first_case'] = "初审日期";
$lang['active_cases'] = "活跃案例";
$lang['critical_cases'] = "重大案件";
$lang['new_deaths_today'] = "今日新死亡";
$lang['mortality_rate'] = "死亡率";
$lang['recovery_rate'] = "恢复率";
$lang['total_tests'] = "全面测试";
?>