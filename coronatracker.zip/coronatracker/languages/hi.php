<?php
$lang = array();
$lang['total_cases'] = "कुल मामले";
$lang['total_deaths'] = "कुल मौतें";
$lang['total_recovered'] = "कुल बरामद";
$lang['location'] = "स्थान";
$lang['confirmed_cases'] = "पुष्टि किए गए मामले";
$lang['deaths'] = "लोगों की मृत्यु";
$lang['recovered'] = "बरामद";
$lang['new_cases_today'] = "आज नए मामले";
$lang['caseper1m'] = "प्रति 1M लोगों पर मामले";
$lang['first_case'] = "पहली केस की तारीख";
$lang['active_cases'] = "सक्रिय मामले";
$lang['critical_cases'] = "गंभीर मामले";
$lang['new_deaths_today'] = "नई मौतें आज";
$lang['mortality_rate'] = "मृत्यु दर";
$lang['recovery_rate'] = "वसूली दर";
$lang['total_tests'] = "कुल टेस्ट";
?>