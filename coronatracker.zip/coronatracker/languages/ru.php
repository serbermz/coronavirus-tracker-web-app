<?php
$lang = array();
$lang['total_cases'] = "Всего случаев";
$lang['total_deaths'] = "Всего смертей";
$lang['total_recovered'] = "Всего восстановлено";
$lang['location'] = "Расположение";
$lang['confirmed_cases'] = "Подтвержденные дела";
$lang['deaths'] = "Смертей";
$lang['recovered'] = "Восстановленные";
$lang['new_cases_today'] = "Новые случаи сегодня";
$lang['caseper1m'] = "Количество случаев на 1 млн. Человек";
$lang['first_case'] = "Дата первого случая";
$lang['active_cases'] = "Активные чехлы";
$lang['critical_cases'] = "Критические случаи";
$lang['new_deaths_today'] = "Новые смерти сегодня";
$lang['mortality_rate'] = "Уровень смертности";
$lang['recovery_rate'] = "Скорость восстановления";
$lang['total_tests'] = "Всего тестов";
?>