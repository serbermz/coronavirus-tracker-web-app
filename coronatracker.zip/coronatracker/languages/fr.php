<?php
$lang = array();
$lang['total_cases'] = "Nombre total de cas";
$lang['total_deaths'] = "Total des décès";
$lang['total_recovered'] = "Total récupéré";
$lang['location'] = "Emplacement";
$lang['confirmed_cases'] = "Cas confirmés";
$lang['deaths'] = "Des morts";
$lang['recovered'] = "Rétabli";
$lang['new_cases_today'] = "De nouveaux cas aujourd'hui";
$lang['caseper1m'] = "Cas pour 1 million de personnes";
$lang['first_case'] = "Date du premier cas";
?>